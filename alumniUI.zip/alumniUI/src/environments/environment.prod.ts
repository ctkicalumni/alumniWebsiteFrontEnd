export const environment = {
  production: true,
  schoolId: 1,
  // apiHost: 'https://localhost/Alumni_association_software/api/',
  apiHost: 'https://www.ctkalumni.org/app-software/api/',
  // apiHost: 'https://www.schoolmanagementsoft.com/app-software/api/',
};
