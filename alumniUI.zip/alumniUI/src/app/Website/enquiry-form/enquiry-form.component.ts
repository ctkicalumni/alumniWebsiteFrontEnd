import { Component, OnInit } from '@angular/core';
import { UntypedFormGroup, UntypedFormControl, Validators } from '@angular/forms';
import { ApiServiceService } from 'src/app/Services/api-service.service';
import { environment } from 'src/environments/environment';

@Component({
    selector: 'app-enquiry-form',
    templateUrl: './enquiry-form.component.html',
    styleUrls: ['./enquiry-form.component.scss'],
    standalone: false
})
export class EnquiryFormComponent implements OnInit {

  enquiry_form: UntypedFormGroup;
  isSubmitted:boolean = false;
  notification: any;
  constructor(private getAPI:ApiServiceService) { }

  ngOnInit(): void {
    this.enquiry_form = new UntypedFormGroup({
      name: new UntypedFormControl('',Validators.required),
      mobile_no: new UntypedFormControl('',[Validators.required, Validators.minLength(10), Validators.maxLength(10), Validators.pattern('[0-9]*')]),
      email: new UntypedFormControl('', [Validators.required, Validators.email]),
      city: new UntypedFormControl('', Validators.required),
      message: new UntypedFormControl('', Validators.required),
      school_id: new UntypedFormControl(environment.schoolId)
    });
  }

  get f() { return this.enquiry_form.controls }

  submitQuery() {
    if(this.enquiry_form.invalid) {
      this.isSubmitted = true;
      return;
    }
    this.getAPI.sendEnquery(this.enquiry_form.value).subscribe((response)=>{
      // console.log(response);
      if(response['status'] == 1) {
        this.notification = {'class':'alert-success show', 'message': response['message']};
      } else {
        this.notification = {'class':'alert-danger show', 'message': response['message']};
      }
      this.enquiry_form.reset();
      this.isSubmitted = false;
    })
  }

}
