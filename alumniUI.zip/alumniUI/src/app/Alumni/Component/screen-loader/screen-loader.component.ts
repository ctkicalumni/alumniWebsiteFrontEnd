import { Component, OnInit, Input } from '@angular/core';

@Component({
    selector: 'app-screen-loader',
    templateUrl: './screen-loader.component.html',
    styleUrls: ['./screen-loader.component.scss'],
    standalone: false
})
export class ScreenLoaderComponent implements OnInit {

  @Input() isShow = false;
  constructor() { }

  ngOnInit(): void {
  }

}
